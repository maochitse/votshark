You got a {weight}% upvote from @{botname} courtesy of @{sender}!
